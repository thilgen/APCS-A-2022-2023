/*
 * Create a class (File) that represents a file in the file system
 *
 *  TODO: A File should have a name and a size
 *
 *  TODO: A File should know its parent Directory
 */

class File {

  public File(Directory parentDirectory, String fileName, int fileSize) {
    
  }
}
