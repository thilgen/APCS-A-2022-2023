import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    // Write a program that asks the user for two 2D points, that is,
    // coordinates (x1, y1) and (x2, y2), as doubles.
    // Calculate the Euclidean distance between the two points and
    // print it out.
    // Here's the distance formula:
    // Distance = sqrt( (x2-x1)^2 + (y2-y1)^2 )

    // Scanner scanner = new Scanner(System.in);
  }
}