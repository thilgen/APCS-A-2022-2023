// See TruthTable.java for instructions.
class Main {
  public static void main(String[] args) {
    new TruthTable();
  }
}