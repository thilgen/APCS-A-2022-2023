public class FizzBuzz {
  //
  // Given an integer i, return a string where:
  // string == "FizzBuzz" if i is divisible by 3 and 5.
  // string == "Fizz" if i is divisible by 3.
  // string == "Buzz" if i is divisible by 5.
  // string == i (as a string) if none of the above conditions are true
  //
  public static String calcFizzBuzz(int i) {
    return "TODO";
  }
}