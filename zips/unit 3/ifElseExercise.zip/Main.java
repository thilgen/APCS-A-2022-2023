import java.util.Scanner;

class Main {
  // Write a program that asks the user for an integer and
  // prints “This number is even” if the number is even,
  // and prints “This number is odd” if the number is odd.

  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);

    // ADD YOUR CODE HERE
  }
}