class Main {
  //
  // See Game.java for instructions on the exercises
  //
  public static void main(String[] args) {
    new Game().play();
  }
}