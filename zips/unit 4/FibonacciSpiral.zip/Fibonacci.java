//
// TODO In this class, implement the next() method to
// return the next number in the Fibonacci sequence
// each time it is called.
//
// The next() implementation will look pretty similar
// to the code in your for loop that output the Fibonacci
// sequence in the previous exercise. The main difference
// is that you will need to track the loop counter and
// previous values as instance variables, not local
// variables. You can initialize these instance variables
// in the constructor.
//
public class Fibonacci {
  public Fibonacci() {
  }

  public long next() {
    // TODO implement me
    return 0;
  }
}