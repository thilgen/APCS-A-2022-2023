import java.util.ArrayList;

public class Table {
  private String tableName;
  private ArrayList<TableColumn> tableColumns;
  private int numColumns;
  private int numRows;
 
  public Table(String tableName, int numColumns, int numRows) {
    /* TODO - WED */
    /* add your code here */
  }

  public int getNumColumns() {
    /* TODO - WED */
    /* add your code here */
    return 0;
  }
  
  public int getNumRows() {
    /* TODO - WED */
    /* add your code here */
    return 0;
  }

  public TableColumn getColumn(int colIdx) {
    /* TODO - WED */
    /* add your code here */
    return null;
  }

  public String getTableName() {
    /* TODO - WED */
    /* add your code here */
    return "";
  }
}
