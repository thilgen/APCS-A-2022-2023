import java.util.ArrayList;

public class TableColumn {
  private ArrayList<Integer> columnValues;

  public TableColumn(int columnValue, int lowMultiplier, int highMultiplier) {
    /* TODO - WED */
    /* add your code here */
  }

  public int getNumRows() {
    /* TODO - WED */
    /* add your code here */
    return 0;
  }

  public int getRowValue(int rowIdx) {
    /* TODO - WED */
    /* add your code here */
    return 0;
  }
}
