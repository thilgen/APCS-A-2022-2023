class Main {
  // See ChartRender.java for instructions
  public static void main(String[] args) {
    new ChartRender().run();
  }
}