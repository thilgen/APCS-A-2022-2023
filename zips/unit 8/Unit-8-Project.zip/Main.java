public class Main {
  // See Game.java for instructions
  public static void main(String[] args) {
    new Game().play();
  }
}