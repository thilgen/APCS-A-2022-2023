public class Date2 {
  public Date2(long msTime) {
    // TODO
  }

  public String getDateInfo() {
    // TODO
    return "";
  }
}