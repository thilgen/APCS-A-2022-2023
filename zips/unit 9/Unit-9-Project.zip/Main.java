// See Game.java for instructions
class Main {
  public static void main(String[] args) {
    new Game().play();
  }
}