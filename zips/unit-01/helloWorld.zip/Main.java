class Main {
  public static void main(String[] args) {
    //prints ot then moves lines
    System.out.println("Hello World!"+(4+2);
    //prints out one line
    System.out.print("Hello World");

    /*
comments here
will not affect
my program
*/
  }
}