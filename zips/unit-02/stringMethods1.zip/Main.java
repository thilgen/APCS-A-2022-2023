public class Main
{
  public static void main(String[] args) {
      String myString = "Hello! My name is Squeamish Ossifrage.";
      
      // Write some code that will print out each word of this sentence
      // line by line. So, your output should be:
      // (Feel free to replace the name)
      // Hello!
      // My
      // name
      // is
      // Squeamish
      // Ossifrage.
      
      // First let's use length to help you out to know how long the string
      // is without you having to count yourself:
      System.out.println("The string is " + myString.length() + " characters long");
      
      // Write your code here:
      // NOTE: YOU CAN'T USE STRING LITERALS. SO NO ""
    }
}