class Main {
  //
  // See the file Game.java for instructions
  //
  public static void main(String[] args) {
    new Game().play();
  }
}