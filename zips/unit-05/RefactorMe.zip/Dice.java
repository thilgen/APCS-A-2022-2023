//
// This class might be a good home for a static method that rolls dice...
//
public class Dice {

}