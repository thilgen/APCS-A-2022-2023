//
// This class could be home to a static method that formats
// numbers between 0.0-1.0 into string percentages ending with a '%' symbol.
//
public class PercentageFormatter {
  
}