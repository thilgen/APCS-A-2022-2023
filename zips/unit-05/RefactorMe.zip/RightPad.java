//
// This class could be a home for a static method that "right pads"
// strings, that is, adds spaces to the right side (end) of the string
// until it's a desired length.
//
public class RightPad {
  
}