class Canvas {

  private String name;
  
  public Canvas(String name, int width, int height) {
    this.name = name;
    // TODO
  }

  public String getName() {
    return name;
  }

  public int getWidth() {
    // TODO
    return Integer.MIN_VALUE;
  }

  public int getHeight() {
    // TODO
    return Integer.MIN_VALUE;
  }

  public void setPixel(int rowIdx, int colIdx, Character pixel) {
    // TODO
  }

  public Character getPixel(int rowIdx, int colIdx) {
    // TODO
    return null;
  }
}
