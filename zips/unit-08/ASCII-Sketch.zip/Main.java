class Main {
  //  See AsciiArt.java for instructions
  public static void main(String[] args) {
    new AsciiArt().run();
  }
}