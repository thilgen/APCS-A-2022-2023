public class FSRecursive {

  public static String getFolderPath(Folder folder) {
    // TODO
    return "TODO";
  }

  public static String[] getFileNames(Folder folder) {
    // TODO
    return new String[]{"TODO"};
  }

  public static String[] getFolderNames(Folder folder) {
    // TODO
    return new String[]{"TODO"};
  }

  public static String[] getFilePaths(Folder folder) {
    // TODO
    return new String[]{"TODO"};
  }
  
}