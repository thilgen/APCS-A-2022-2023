import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class PlayerTests {

  @Test
  public void PlayerTest1() {
    // TODO - add test for Player object - Check out ContactTests for an example
    assertEquals("", "nope");
  }

  @Test
  public void PlayerTest2() {
    // TODO - add test for Player object - Check out ContactTests for an example
    assertEquals(true, false);
  }

  @Test
  public void PlayerTest3() {
    // TODO - add test for Player object - Check out ContactTests for an example
    assertEquals("", "nope");
  }
}
