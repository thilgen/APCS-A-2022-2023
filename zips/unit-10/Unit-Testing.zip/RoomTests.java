import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class RoomTests {

  @Test
  public void RoomTest1() {
    // TODO - add test for Room object - Check out ContactTests for an example
    assertEquals("", "nope");
  }

  @Test
  public void RoomTest2() {
    // TODO - add test for Room object - Check out ContactTests for an example
    assertEquals(true, false);
  }

  @Test
  public void RoomTest3() {
    // TODO - add test for Room object - Check out ContactTests for an example
    assertEquals("", "nope");
  }
}
